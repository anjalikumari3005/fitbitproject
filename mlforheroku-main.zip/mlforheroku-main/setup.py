from setuptools import setup, find_packages

setup(
    name="machine-learning",
    version="0.0.3",
    description="machine-learning",
    author="Avnish yadav", 
    packages=find_packages(),
    license="MIT"
)