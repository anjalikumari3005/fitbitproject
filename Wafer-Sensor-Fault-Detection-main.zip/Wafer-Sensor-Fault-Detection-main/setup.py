from setuptools import setup, find_packages

setup(
    name="Wafer-Fault-Detection",
    version="0.0.3",
    description="ML project",
    author="Mayur Borkar",
    packages=find_packages(),
    license="MIT"
)